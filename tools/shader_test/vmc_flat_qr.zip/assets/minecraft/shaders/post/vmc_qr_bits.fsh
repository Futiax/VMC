#version 330
#extension GL_ARB_separate_shader_objects : require

// GENERE par gen_qr_detect.py -- ne pas editer a la main.
// qr_bits, passe d'affichage : sur chaque module du QR, le bit lu par vmc_qr_sample -- 1 vert
// sur un module clair, 0 rouge sur un sombre, ? jaune ni l'un ni l'autre. Le chiffre est
// dessine DANS le module avec la meme grille que l'echantillonnage : s'il deborde sur le
// voisin, c'est la grille qui a derive, pas la lecture.
// ATTENTION : la norme QR fait l'inverse (module sombre = bit 1). Ici clair = 1, a la demande.

uniform sampler2D InSampler;    // bits 57x57
uniform sampler2D FitSampler;   // fit 4x1
uniform sampler2D SrcSampler;   // image d'origine

layout(location = 0) out vec4 fragColor;

const int QR_N = 57;
const float SPAN = 50.0;
const int QMARK = 29314;
const int SC = 4;
const int FONT[10] = int[10](31599, 11415, 29671, 29647, 23497, 31183, 31215, 29257, 31727, 31695);

ivec4 fitAt(int i) {
    return ivec4(round(texelFetch(FitSampler, ivec2(i, 0), 0) * 255.0));
}

vec2 point(int i) {
    ivec4 t = fitAt(i);
    return vec2(float(t.r | ((t.b & 15) << 8)), float(t.g | ((t.b >> 4) << 8)));
}

// nombre a 3 chiffres (zeros compris) dont le coin bas-gauche est en o
bool digits3(ivec2 p, ivec2 o, int value) {
    ivec2 q = p - o;
    if (q.x < 0 || q.y < 0 || q.x >= 12 * SC || q.y >= 5 * SC) return false;
    int fx = q.x / SC, fy = q.y / SC;
    int di = fx / 4, cx = fx - di * 4;
    if (cx >= 3) return false;
    int power = di == 0 ? 100 : (di == 1 ? 10 : 1);
    int glyph = FONT[(value / power) % 10];
    // gl_FragCoord.y monte, la police descend : on retourne la ligne
    return ((glyph >> (14 - ((4 - fy) * 3 + cx))) & 1) == 1;
}

// HUD en haut a gauche : fond sombre, pastille, motif de rejet / tuiles / candidats / 16
vec3 hud(ivec2 p, ivec2 size, ivec4 st, vec3 col) {
    ivec2 o = ivec2(8, size.y - 8 - 20);
    ivec2 q = p - o;
    if (q.x >= -4 && q.y >= -4 && q.x < 24 + 3 * 13 * SC && q.y < 20 + 4) {
        col = col * 0.25;
        if (q.x >= 0 && q.y >= 0 && q.x < 20 && q.y < 20) {
            col = st.a == 255 ? vec3(0.1, 0.9, 0.2) : vec3(0.9, 0.15, 0.1);
        }
        if (digits3(p, o + ivec2(24, 0), st.b) || digits3(p, o + ivec2(24 + 13 * SC, 0), st.r)
                || digits3(p, o + ivec2(24 + 26 * SC, 0), st.g)) {
            col = vec3(1.0);
        }
    }
    return col;
}

void main() {
    ivec2 p = ivec2(gl_FragCoord.xy);
    ivec2 size = textureSize(SrcSampler, 0);
    vec3 col = texelFetch(SrcSampler, p, 0).rgb;
    ivec4 st = fitAt(3);
    if (st.a == 255) {
        vec2 tl = point(0);
        // colonnes : un module le long de TL->TR, un module le long de TL->BL
        mat2 g = mat2((point(1) - tl) / SPAN, (point(2) - tl) / SPAN);
        vec2 uv = inverse(g) * (vec2(p) - tl) + 3.5;   // en modules, 3,5 = centre du repere TL
        if (all(greaterThanEqual(uv, vec2(0.0))) && all(lessThan(uv, vec2(float(QR_N))))) {
            ivec2 ij = ivec2(floor(uv));
            vec2 f = uv - vec2(ij);
            int c = int(round(texelFetch(InSampler, ij, 0).r * 255.0));
            // glyphe 3x5 au milieu du module ; f.y descend vers BL comme les lignes de FONT,
            // donc pas de retournement ici, et le chiffre suit la rotation du QR
            int gx = int(floor((f.x - 0.2) / 0.6 * 3.0));
            int gy = int(floor((f.y - 0.1) / 0.8 * 5.0));
            if (gx >= 0 && gx < 3 && gy >= 0 && gy < 5) {
                int glyph = c == 2 ? FONT[1] : (c == 1 ? FONT[0] : QMARK);
                if (((glyph >> (14 - (gy * 3 + gx))) & 1) == 1) {
                    col = c == 2 ? vec3(0.1, 0.8, 0.2)
                                 : (c == 1 ? vec3(1.0, 0.2, 0.15) : vec3(1.0, 0.85, 0.0));
                }
            }
        }
    }
    fragColor = vec4(hud(p, size, st, col), 1.0);
}
