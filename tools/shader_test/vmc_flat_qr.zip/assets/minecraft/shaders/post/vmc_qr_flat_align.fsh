#version 330
#extension GL_ARB_separate_shader_objects : require

uniform sampler2D InSampler;
uniform sampler2D SrcSampler;
layout(location = 0) out vec4 fragColor;

ivec2 pointAt(int i) {
    ivec4 t = ivec4(round(texelFetch(InSampler, ivec2(i, 0), 0) * 255.0));
    return ivec2(t.r | ((t.b & 15) << 8), t.g | ((t.b >> 4) << 8));
}

void putPoint(ivec2 p) {
    p = clamp(p, ivec2(0), ivec2(4095));
    fragColor = vec4(float(p.x & 255), float(p.y & 255),
                     float((p.x >> 8) | ((p.y >> 8) << 4)), 255.0) / 255.0;
}

int cls(ivec2 p, ivec2 size) {
    if (any(lessThan(p, ivec2(0))) || any(greaterThanEqual(p, size))) return 0;
    float y = dot(texelFetch(SrcSampler, p, 0).rgb,
                  vec3(0.2126, 0.7152, 0.0722));
    return y < 0.25 ? 1 : (y > 0.70 ? 2 : 0);
}

int score(ivec2 p, ivec2 size, int module) {
    int s = 0;
    for (int y = -2; y <= 2; y++)
        for (int x = -2; x <= 2; x++) {
            int want = (abs(x) == 2 || abs(y) == 2 || (x == 0 && y == 0)) ? 1 : 2;
            s += cls(p + ivec2(x, y) * module, size) == want ? 1 : 0;
        }
    return s;
}

void main() {
    int i = int(gl_FragCoord.x);
    if (i >= 6 || int(round(texelFetch(InSampler, ivec2(3, 0), 0).a * 255.0)) != 255) {
        fragColor = vec4(0.0);
        return;
    }
    // v10 alignment centers: (6,28), (28,6), (28,28), (28,50), (50,28), (50,50).
    const ivec2 q[6] = ivec2[6](ivec2(6,28), ivec2(28,6), ivec2(28,28),
                                 ivec2(28,50), ivec2(50,28), ivec2(50,50));
    ivec2 tl = pointAt(0);
    ivec2 u = pointAt(1) - tl;
    ivec2 v = pointAt(2) - tl;
    float module = max(1.0, sqrt(length(u) * length(v)) / 50.0);
    vec2 predicted = vec2(tl) + (float(q[i].x) - 3.5) * vec2(u) / 50.0
                                  + (float(q[i].y) - 3.5) * vec2(v) / 50.0;
    ivec2 center = ivec2(floor(predicted + 0.5));
    ivec2 size = textureSize(SrcSampler, 0);
    ivec2 best = center;
    int bestScore = -1;
    int radius = int(min(module * 2.0, 24.0));
    int step = max(1, int(module / 4.0));
    for (int y = -24; y <= 24; y++) for (int x = -24; x <= 24; x++) {
        if (abs(x) > radius || abs(y) > radius || (x % step) != 0 || (y % step) != 0) continue;
        ivec2 p = center + ivec2(x, y);
        int s = score(p, size, max(1, int(module)));
        if (s > bestScore) { bestScore = s; best = p; }
    }
    putPoint(best);
}
