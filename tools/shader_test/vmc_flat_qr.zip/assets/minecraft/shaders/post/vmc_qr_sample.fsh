#version 330
#extension GL_ARB_separate_shader_objects : require

// GENERE par gen_qr_detect.py -- ne pas editer a la main.
// qr_bits, passe sample : cible 57x57, un fragment par module (x = colonne, y = ligne,
// ligne 0 = celle du repere TL). Etat du pixel d'ecran au CENTRE du module, 0/1/2 comme
// cls(), sur une grille AFFINE posee sur les 3 reperes : exacte de face, fausse des que
// l'ecran n'est plus parallele a la camera (1 degre suffit a fausser le coin oppose a TL).
// Transcription de sample_bits() : en centiemes de pixel et en entiers, donc le meme pixel
// que numpy au bit pres.

uniform sampler2D InSampler;    // fit 4x1
uniform sampler2D SrcSampler;   // image d'origine

layout(location = 0) out vec4 fragColor;

const vec3 LUMA = vec3(0.2126, 0.7152, 0.0722);
const float DARK_T = 0.25;
const float LIGHT_T = 0.7;

// 0 = ni sombre ni clair, 1 = sombre, 2 = clair. Hors ecran = 0 : texelFetch hors texture
// est indefini, et une plage doit s'arreter au bord comme dans la simulation.
int cls(ivec2 p, ivec2 size) {
    if (any(lessThan(p, ivec2(0))) || any(greaterThanEqual(p, size))) return 0;
    float y = dot(texelFetch(SrcSampler, p, 0).rgb, LUMA);
    return y < DARK_T ? 1 : (y > LIGHT_T ? 2 : 0);
}

ivec2 pointAt(int i) {
    ivec4 t = ivec4(round(texelFetch(InSampler, ivec2(i, 0), 0) * 255.0));
    return ivec2(t.r | ((t.b & 15) << 8), t.g | ((t.b >> 4) << 8));
}

void main() {
    ivec2 m = ivec2(gl_FragCoord.xy);
    fragColor = vec4(0.0);
    if (int(round(texelFetch(InSampler, ivec2(3, 0), 0).a * 255.0)) != 255) return;
    ivec2 tl = pointAt(0), u = pointAt(1) - tl, v = pointAt(2) - tl;
    // reperes aux centres des modules 3 et 53 : centre du module (i, j) =
    // TL + (i - 3)/50 U + (j - 3)/50 V, ici en centiemes de pixel, +50 pour arrondir
    ivec2 p100 = 100 * tl + (2 * m.x - 6) * u + (2 * m.y - 6) * v + 50;
    // hors ecran (etat 0) ; teste AVANT la division, qui tronquerait un negatif vers 0
    if (p100.x < 0 || p100.y < 0) return;
    fragColor = vec4(float(cls(p100 / 100, textureSize(SrcSampler, 0))) / 255.0, 0.0, 0.0, 1.0);
}
