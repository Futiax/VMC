#version 330
#extension GL_ARB_separate_shader_objects : require

uniform sampler2D BitsSampler;
uniform sampler2D FitSampler;
uniform sampler2D AlignSampler;
uniform sampler2D SrcSampler;
layout(location = 0) out vec4 fragColor;

const int MODULE = 8;
const int QR_N = 57;

ivec2 pointAt(int i) {
    ivec4 t = ivec4(round(texelFetch(FitSampler, ivec2(i, 0), 0) * 255.0));
    return ivec2(t.r | ((t.b & 15) << 8), t.g | ((t.b >> 4) << 8));
}

ivec2 alignAt(int i) {
    ivec4 t = ivec4(round(texelFetch(AlignSampler, ivec2(i, 0), 0) * 255.0));
    return ivec2(t.r | ((t.b & 15) << 8), t.g | ((t.b >> 4) << 8));
}

bool finder(int x, int y, out bool dark) {
    ivec2 o = x < 7 ? ivec2(0, 0) : (x >= 50 ? ivec2(50, 0) : ivec2(0, 50));
    if (!((x >= o.x - 1 && x <= o.x + 7) && (y >= o.y - 1 && y <= o.y + 7))) return false;
    if (x < o.x || x > o.x + 6 || y < o.y || y > o.y + 6) {
        dark = false;
    } else {
        int dx = x - o.x, dy = y - o.y;
        dark = max(abs(dx - 3), abs(dy - 3)) != 2;
    }
    return true;
}

bool alignment(int x, int y, out bool dark) {
    for (int ry = 0; ry < 3; ry++) for (int rx = 0; rx < 3; rx++) {
        int cx = rx == 0 ? 6 : (rx == 1 ? 28 : 50);
        int cy = ry == 0 ? 6 : (ry == 1 ? 28 : 50);
        if ((cx == 6 && cy == 6) || (cx == 50 && cy == 6)
                || (cx == 6 && cy == 50)) continue;
        if (abs(x - cx) <= 2 && abs(y - cy) <= 2) {
            dark = max(abs(x - cx), abs(y - cy)) != 1;
            return true;
        }
    }
    return false;
}

void main() {
    ivec2 outp = ivec2(gl_FragCoord.xy);
    ivec2 screen = textureSize(SrcSampler, 0);
    vec3 scene = texelFetch(SrcSampler, outp, 0).rgb;
    ivec2 local = ivec2(outp.x, screen.y - 1 - outp.y);
    if (local.x >= QR_N * MODULE || local.y >= QR_N * MODULE) {
        fragColor = vec4(scene, 1.0); return;
    }
    if (int(round(texelFetch(FitSampler, ivec2(3, 0), 0).a * 255.0)) != 255) {
        fragColor = vec4(scene, 1.0); return;
    }
    ivec2 module = local / MODULE;
    bool dark;
    if (finder(module.x, module.y, dark) || alignment(module.x, module.y, dark)) {
        fragColor = vec4(dark ? vec3(0.02) : vec3(0.98), 1.0);
        return;
    }
    ivec2 tl = pointAt(0);
    vec2 u = vec2(pointAt(1) - tl);
    vec2 v = vec2(pointAt(2) - tl);
    vec2 source = vec2(tl) + (float(module.x) - 3.5) * u / 50.0
                              + (float(module.y) - 3.5) * v / 50.0;
    // Correct the affine estimate with the six alignment centers. Their residuals
    // vary smoothly across the QR under perspective.
    vec2 correction = vec2(0.0);
    float weight = 0.0;
    for (int i = 0; i < 6; i++) {
        ivec2 grid = i == 0 ? ivec2(6, 28) : (i == 1 ? ivec2(28, 6)
            : (i == 2 ? ivec2(28, 28) : (i == 3 ? ivec2(28, 50)
            : (i == 4 ? ivec2(50, 28) : ivec2(50, 50)))));
        ivec4 valid = ivec4(round(texelFetch(AlignSampler, ivec2(i, 0), 0) * 255.0));
        if (valid.w == 0) continue;
        vec2 predicted = vec2(tl) + (float(grid.x) - 3.5) * u / 50.0
                                      + (float(grid.y) - 3.5) * v / 50.0;
        vec2 delta = vec2(alignAt(i)) - predicted;
        vec2 d = vec2(module - grid);
        float w = 1.0 / max(dot(d, d), 1.0);
        correction += delta * w;
        weight += w;
    }
    if (weight > 0.0) source += correction / weight;
    ivec2 sample = ivec2(floor(source + 0.5));
    if (any(lessThan(sample, ivec2(0)))
            || any(greaterThanEqual(sample, textureSize(SrcSampler, 0)))) {
        fragColor = vec4(scene, 1.0);
        return;
    }
    fragColor = vec4(texelFetch(SrcSampler, sample, 0).rgb, 1.0);
}
